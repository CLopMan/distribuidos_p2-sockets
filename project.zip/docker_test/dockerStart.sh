#!/bin/bash

docker network create sc_testing
docker run -d --net sc_testing --name cliente ubuntu:latest
docker run -d --net sc_testing --name servidor fedora:latest

docker cp ../src/* servidor:~
docker cp ../src/* cliente:~
